// creates a react arrow function export component.


import React, { useState } from 'react'
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import'./Add.css';

const Add = () => {
  const [movie,setMovie]=useState({
    MovieName:'',
    ReleaseYear:'',
    Category:'',
    Director:'',
    Language:''
  });

  const extract=(e)=>{
    setMovie({...movie,[e.target.name]:e.target.value});

  };
 
  const datasubmit=()=>{
    console.log(movie);
    alert('data Submited')
  }

  return (
    <>
    <div class="add">
      <h2 class="head"><i>Add Movie</i></h2><br />
      <TextField id="outlined-basic" onChange={extract} label="Movie Name" variant="outlined"  name='MovieName'/><br /><br />
      <TextField id="outlined-basic" onChange={extract} label="Release Year" variant="outlined" name="ReleaseYear" /><br /><br />
      <TextField id="outlined-basic" onChange={extract} label="Category" variant="outlined"  name="Category"/><br /><br />
      <TextField id="outlined-basic" onChange={extract} label="Director" variant="outlined" name="Director"/><br /><br />
      <TextField id="outlined-basic" onChange={extract} label="Language" variant="outlined" name="Language" /><br /><br />
      <Button variant="contained" color="success" onClick={datasubmit} >
        Submit
      </Button>
    </div>
      
    </>
  )
}

export default Add