import * as React from 'react';
import { styled } from '@mui/material/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';


const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
      backgroundColor: theme.palette.common.black,
      color: theme.palette.common.white,
    },
    [`&.${tableCellClasses.body}`]: {
      fontSize: 14,
    },
  }));
  
  const StyledTableRow = styled(TableRow)(({ theme }) => ({
    '&:nth-of-type(odd)': {
      backgroundColor: theme.palette.action.hover,
    },
    // hide last border
    '&:last-child td, &:last-child th': {
      border: 20,
    },
  }));
  
function createData(id ,Moviename, Releaseyear, Category, Director, Language) {
    return {id ,Moviename, Releaseyear, Category, Director, Language};
  }
  
  const rows = [
    createData(1,'Premalu',2024, 'romantic comedy film','Girish A. D.','Malayalam'),
    createData(2, '2018', 2023, 'drama survival film', 'Jude Anthany Joseph', 'Malayalam'),
    createData(3, 'Aarattu', 2022, 'action drama film', 'B. Unnikrishnan', 'Malayalam'),
    createData(4, 'Nanpakal Nerathu Mayakkam', 2023, 'drama film', 'Lijo Jose Pellissery', 'Malayalam'),
    createData(5, 'Palthu Janwar', 2022, 'comedy drama film', 'Sangeeth P. Rajan', 'Malayalam'),

  ];
  

const Home = () => {
  return (
    <>
          <TableContainer component={Paper}>
      <Table sx={{ minWidth: 700 }} aria-label="customized table">
        <TableHead>
          <TableRow>
          <StyledTableCell align='center'>SI No:</StyledTableCell>
            <StyledTableCell align='center'>Movie Name</StyledTableCell>
            <StyledTableCell align="center">Release-year</StyledTableCell>
            <StyledTableCell align="center">Category</StyledTableCell>
            <StyledTableCell align="center">Director</StyledTableCell>
            <StyledTableCell align="center">Language</StyledTableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row) => (
            <StyledTableRow key={row.id}>
              <StyledTableCell component="th" scope="row">
                {row.id}
              </StyledTableCell>
              <StyledTableCell align="center">{row.Moviename}</StyledTableCell>
              <StyledTableCell align="center">{row.Releaseyear}</StyledTableCell>
              <StyledTableCell align="center">{row.Category}</StyledTableCell>
              <StyledTableCell align="center">{row.Director}</StyledTableCell>
              <StyledTableCell align="center">{row.Language}</StyledTableCell>
            </StyledTableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
     
    </>
  )
}

export default Home