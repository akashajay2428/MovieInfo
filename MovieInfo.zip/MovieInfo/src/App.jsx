import { useState } from 'react'
import './App.css'
import Home from './Components/Home'
import Add from './Components/Add'
import Nav from './Components/nav'
import { Route, Routes } from 'react-router-dom'



function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      {/* <div className="navbar">
      <Nav/>
      </div>
      <Routes/>
      <div class="main">
      <div class="one">
      <Route path="/" element={<Home/>}></Route>
      

      </div>
      <div class="two">
      <Route path="/add" element={<Add/>}></Route>
      </div>
      </div>
      <Routes/> */}
      
    <>
    
     <Nav/>
     <Routes>
      <Route path='/' element={<Home/>}></Route>
      <Route path='/add' element={<Add/>}></Route>
     </Routes>
    </>
  


     
    </>
  )
}

export default App
